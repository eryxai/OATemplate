#region Using ...
using System;
#endregion

/*
 
 
 */
namespace Framework.Common.Interfaces
{
    /// <summary>
    /// 
    /// </summary>
    public interface ICreationTimeSignature
	{
		#region Properties
		DateTime CreationDate { get; set; }
		#endregion
	}
}
