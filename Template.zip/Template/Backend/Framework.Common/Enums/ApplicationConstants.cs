﻿namespace Framework.Common.Enums
{
    public class ApplicationConstants
	{
		public static int AuthFailureCode
		{
			get { return 401; }
		}
	}
}
