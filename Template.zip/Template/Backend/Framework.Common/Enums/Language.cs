#region Using ...
#endregion

/*
 
 
 */
namespace Framework.Common.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum Language : byte
	{
		/// <summary>
		/// 
		/// </summary>
		None = 0,
		/// <summary>
		/// 
		/// </summary>
		Arabic,
		/// <summary>
		/// 
		/// </summary>
		English
	}
}
