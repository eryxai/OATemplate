#region Using ...
#endregion

/*
 
 
 */
namespace Framework.Common.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum Order : byte
	{
		Ascending = 0,
		Descending
	}
}
