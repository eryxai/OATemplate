﻿namespace Framework.Core.QueryFilters
{
    public class TableFilterContext
    {
        public object Value { get; set; }
        public string MatchMode { get; set; }
        public string Operator { get; set; }
    }
}
