#region Using ...
#endregion

/*
 
 
 */
namespace TemplateService.Core.Models.ViewModels.Base
{
    /// <summary>
    /// 
    /// </summary>
    public class BaseViewModel
	{

	}
}
