#region Using ...
#endregion

/*
 
 
 */
namespace TemplateService.Core.IServices.Base
{
    /// <summary>
    /// 
    /// </summary>
    public interface IBaseService
	{

	}
}
