#region Using ...
using System;
using TemplateService.Entity.Entities;
using TemplateService.Core.IRepositories.Base;
#endregion

/*


*/
namespace TemplateService.DataAccess.Repositories
{
    /// <summary>
    /// 
    /// </summary>
    public interface IExperienceRepositoryAsync : IBaseServiceRepositoryAsync<Experience, long>
    {
      


    }
}
