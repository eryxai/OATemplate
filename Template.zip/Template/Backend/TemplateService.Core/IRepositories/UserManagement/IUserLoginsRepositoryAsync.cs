#region Using ...
using TemplateService.Entity.Entities;
#endregion

/*


*/
namespace TemplateService.Core.IRepositories
{
    /// <summary>
    /// 
    /// </summary>
    public interface IUserLoginsRepositoryAsync : Base.IBaseServiceRepositoryAsync<UserLogin, long>
    {

    }
}
