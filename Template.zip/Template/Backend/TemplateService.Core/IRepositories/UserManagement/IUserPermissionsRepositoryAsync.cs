#region Using ...
using TemplateService.Entity.Entities;
#endregion

/*


*/
namespace TemplateService.Core.IRepositories
{
    /// <summary>
    /// 
    /// </summary>
    public interface IUserPermissionsRepositoryAsync : Base.IBaseServiceRepositoryAsync<UserPermission, long>
    {

    }
}
