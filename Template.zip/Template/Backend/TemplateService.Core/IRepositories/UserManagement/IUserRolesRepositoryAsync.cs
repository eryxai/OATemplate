#region Using ...
using TemplateService.Entity.Entities;
#endregion

/*


*/
namespace TemplateService.Core.IRepositories
{
    /// <summary>
    /// 
    /// </summary>
    public interface IUserRolesRepositoryAsync : Base.IBaseServiceRepositoryAsync<UserRole, long>
    {

    }
}
