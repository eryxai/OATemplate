#region Using ...
using TemplateService.Entity.Entities;
#endregion

/*


*/
namespace TemplateService.Core.IRepositories
{
    /// <summary>
    /// 
    /// </summary>
    public interface IPermissionGroupRepositoryAsync : Base.IBaseServiceRepositoryAsync<PermissionGroup, long>
    {

    }
}
