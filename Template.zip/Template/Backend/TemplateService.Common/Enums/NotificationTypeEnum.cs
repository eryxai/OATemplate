namespace TemplateService.Common.Enums
{
    public enum NotificationTypeEnum
    {
        Alert = 1,
        AlertWithPopup = 2
    }
}
