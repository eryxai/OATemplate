namespace TemplateService.Common.Enums
{
    public  enum AttachmentType : byte
    {
        AdvertisingDetails=1,
        DataEntryImport = 2,
        Violation = 3,
        AdvertiserFiles=4,
        Locations=5,
    }
}
