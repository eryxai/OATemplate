namespace TemplateService.Common.Enums
{
    public enum ObjectTypeAttachmentEnum
    {
        User = 1,
        OrganizationIcon , 
        NewsImage , 
        BannerImage, 
        FlowFile,
        FlowPDF,
    }
}
