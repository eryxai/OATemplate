#region Using ...
using Microsoft.AspNetCore.Mvc;
#endregion

/*
 
 
 */
namespace TemplateService.WebAPI.Controllers.APIControllers.Base
{
    /// <summary>
    /// 
    /// </summary>
    [ApiController]
	public class BaseAPIController : ControllerBase
	{

	}
}
