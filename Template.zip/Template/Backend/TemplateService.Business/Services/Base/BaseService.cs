#region Using ...
#endregion

/*
 
 
 */
namespace TemplateService.Business.Services.Base
{
    /// <summary>
    /// 
    /// </summary>
    public interface BaseService
	{

	}
}
