using Microsoft.AspNetCore.SignalR;

namespace TemplateService.Business.Helper.SignalR
{
    public class NotifyTemplateHub : Hub<ITypedHubClient>
    {
       
    }
}
