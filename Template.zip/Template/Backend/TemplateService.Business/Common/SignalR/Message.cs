namespace TemplateService.Business.Helper.SignalR
{
    public class Message
    {
        public string Type { get; set; }
        public string Payload { get; set; }
    }
}
