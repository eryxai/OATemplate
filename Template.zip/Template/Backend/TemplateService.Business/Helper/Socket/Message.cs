namespace TemplateService.Business.Helper.Socket
{
    public class Message
    {
        public string Type { get; set; }
        public string Payload { get; set; }
    }
}
