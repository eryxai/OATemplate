export class ChangePasswordViewModel {
  userId!: number;
  oldPassword!: string;
  newPassword!: string;
  confirmPassword!: string;
}
