export class Login {
  userName?: string;
  email?: string;
  password!: string;
}
