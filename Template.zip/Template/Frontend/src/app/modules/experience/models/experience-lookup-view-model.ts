export class ExperienceLookupViewModel {
    id!: number;

    name!: string;
    parentId!: number | null;
    parentName!: string;
}