export enum RiskTypesEnum {
  High = 1,
  Low = 2,
}
