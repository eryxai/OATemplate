export enum Colors {
  primary_main0 = '#005256',
  primary_main1 = '#064b78',
  primary_main2 = '#d8e990',
  primary_main3 = '#D8F7FF',
  primary_main4 = '#ff544f',
  primary_main5 = '#656565',
  grey = '#6a6565',
  white = '#fff',
}
