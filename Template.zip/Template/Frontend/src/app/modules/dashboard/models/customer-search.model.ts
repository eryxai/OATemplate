import { BaseFilter } from 'src/app/sharedFeatures/models/base-filter.model';

export class CustomerSearch extends BaseFilter {
    historyApprovalType!: string;
}
