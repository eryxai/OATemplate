export class RoleLightViewModel {
  id!: number;
  name!: string;
  
  description!: string;
  creationDate!: Date;
}
