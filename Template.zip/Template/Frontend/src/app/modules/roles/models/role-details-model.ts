export class RoleDetailModel {
  descriptionAr!: string;
  descriptionEn!: string;
  nameEn!: string;
  nameAr!: string;

  organizationId!: number;
  organizationName!: string;
  id!: number;
}
