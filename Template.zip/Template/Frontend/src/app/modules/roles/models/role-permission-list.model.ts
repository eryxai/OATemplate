export class RolePermissionListViewModel {
  roleId!: number;
  list: NameValueViewModel[] = [];
}

export class NameValueViewModel {
  value!: number;
  name!: string;
}
