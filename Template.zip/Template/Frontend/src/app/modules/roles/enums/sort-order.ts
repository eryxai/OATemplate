export enum RoleSortOrder {
  Id = 'id',
  Name = 'name',
  OrganizationName = 'organizationName',
  CreationDate = 'creationDate',
  Description = 'description',
}
