export enum HistoryApprovalTypeEnum {
  Approve = 1,
  Draft = 2,
  Reject = 3,
}
