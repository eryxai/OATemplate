export enum AttachmentTypeEnum{
    dataEntryImport = 1
}