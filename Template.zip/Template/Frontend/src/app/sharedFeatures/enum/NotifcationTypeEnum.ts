export enum NotificationTypeEnum {
    Alert = 1,
    AlertWithPopup = 2
}