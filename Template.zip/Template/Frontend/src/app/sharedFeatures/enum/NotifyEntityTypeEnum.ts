export enum NotifyEntityTypeEnum {
  Wrong = 1,
  Transactions,
  Notification,
  ReloadMenu,
  CameraTransactions,
}
