export enum ApprovalTypeEnum {
  Approve = 1,
  Draft = 2,
  Reject = 3,
}
