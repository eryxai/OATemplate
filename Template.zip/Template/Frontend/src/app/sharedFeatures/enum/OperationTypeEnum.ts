export enum OperationTypeEnum {
  positive = 1,
  minus = 2,
}
