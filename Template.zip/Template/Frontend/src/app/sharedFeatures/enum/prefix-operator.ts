export enum PrefixOperator {
  Multiply = 1,
  Division,
  Plus,
  Minus,
}
