export enum EnergyMatrixTypeEnum {
  Approve = 1,
  Draft = 2,
  Reject = 3,
}
