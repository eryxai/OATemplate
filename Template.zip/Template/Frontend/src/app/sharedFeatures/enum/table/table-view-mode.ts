export enum TableViewMood {
  RecordsView = 1,
  GroupView,
}
