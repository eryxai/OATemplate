export enum TableHeaderType {
  Text = 'text',
  Numeric = 'numeric',
  Boolean = 'boolean',
  Date = 'date',
  Enum = 'enum',
  Avatar = 'Avatar',
  Location = 'Location',
}
