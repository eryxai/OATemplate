export enum ViolationStatusEnum {
  New = '1',
  Review = '2',
  Close = '3',
}
export enum ViolationStatus {
  New = 1,
  Review = 2,
  Close = 3,
}
