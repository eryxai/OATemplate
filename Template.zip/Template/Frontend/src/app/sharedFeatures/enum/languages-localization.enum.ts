export enum LanguagesLocalization {
  AR = 'ar',
  EN = 'en',
}
