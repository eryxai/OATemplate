export enum FacilityType {
  secured = 1,
  unsecured = 2,
}
