export enum SurveyQuestionType {
    YesNoNA=1,
    MultipleChoice,
    MultipleSelect,
    OpenEnded,
    DateTime,
    Dropdown
  }
  