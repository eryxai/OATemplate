export enum TypeEnum {
  NEBT = 1,
  Chart = 2,
}
