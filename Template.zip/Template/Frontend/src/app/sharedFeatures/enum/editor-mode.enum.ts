export enum EditorMode {
  add = 0,
  edit,
  detail,
  search,
}
