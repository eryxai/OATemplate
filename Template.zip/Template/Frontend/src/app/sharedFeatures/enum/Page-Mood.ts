export enum PageMood {
  create = 1,
  details,
  edit,
  approve,
}
