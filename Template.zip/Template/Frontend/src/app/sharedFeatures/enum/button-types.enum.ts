export enum ButtonTypes {
  primary = "primary",
  primaryAccent = "primaryAccent",
  secondary = "secondary",
  gradient = "gradient"
}
