export class FieldSort {
  name: string = 'id';
  sortASC: boolean = false;
}
