export interface DropdownItem {
  id: string | number;
  name: string;
}
