export interface RoomLookupViewModel
{
    id:string;
    name:string;
}