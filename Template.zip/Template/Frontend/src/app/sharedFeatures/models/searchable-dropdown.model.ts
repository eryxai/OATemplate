import { BaseFilter } from './base-filter.model';

export class ISearchableDropdown extends BaseFilter {
  name!: string;
}
