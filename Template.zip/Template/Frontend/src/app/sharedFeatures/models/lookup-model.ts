export interface LookupModel {
  id: number;
  name: string;
  parentId:number;
}
