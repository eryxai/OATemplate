export enum Language {
  None = 0,
  Arabic = 1,
  English = 2,
}
