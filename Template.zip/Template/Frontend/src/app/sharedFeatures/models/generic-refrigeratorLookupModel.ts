export interface RefrigeratorLookupViewModel
{
    id:string;
    name:string;
}